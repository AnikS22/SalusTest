# SALUS A100 Deployment Package

This package contains everything needed to deploy SALUS on an A100 HPC.

## Quick Start

1. **Transfer to HPC:**
   ```bash
   scp -r salus_a100_deployment_* username@hpc_address:~/
   ssh username@hpc_address
   cd salus_a100_deployment_*
   ```

2. **Run setup:**
   ```bash
   bash hpc_setup.sh
   bash setup_rclone.sh
   bash test_salus.sh
   ```

3. **Deploy:**
   ```bash
   bash deploy_a100.sh collect 500 8
   ```

## Documentation

- **HPC_DEPLOYMENT.md** - Complete deployment guide
- **A100_SCALING_GUIDE.md** - Technical details and optimization
- **DATA_MANAGEMENT_GUIDE.md** - Rclone backup strategies

## Support

If you encounter issues, check:
1. HPC_DEPLOYMENT.md - Troubleshooting section
2. Log files in a100_logs/
3. Test with 1 episode first: `bash test_salus.sh`

## Timeline

- Setup: 15 minutes
- Test: 13 minutes
- Data collection: ~50 hours (500 episodes)
- Training: 15 minutes
- **Total: ~51 hours**

Expected results: F1 > 0.60 (2× better than PoC)
