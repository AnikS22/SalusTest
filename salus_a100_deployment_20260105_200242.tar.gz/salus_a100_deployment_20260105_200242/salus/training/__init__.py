"""training module"""
