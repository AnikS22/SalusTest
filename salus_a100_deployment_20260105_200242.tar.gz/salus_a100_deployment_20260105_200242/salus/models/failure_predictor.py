"""
SALUS Failure Predictor Network
Predicts failure probability at multiple horizons from VLA internal signals.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Tuple


class FailurePredictor(nn.Module):
    """
    Predicts failure probability at multiple horizons.

    Input: VLA signals (attention, uncertainty, hidden states)
    Output: Failure probability for each (horizon, failure_type) pair

    Architecture: [12, 64, 128, 128, 64, 16]
    """

    def __init__(
        self,
        input_dim: int = 12,
        hidden_dims: list = [64, 128, 128, 64],
        num_horizons: int = 4,
        num_failure_types: int = 4,
        dropout: float = 0.2
    ):
        """
        Initialize failure predictor.

        Args:
            input_dim: Input signal dimension (12D VLA signals)
            hidden_dims: Hidden layer dimensions
            num_horizons: Number of prediction horizons (4)
            num_failure_types: Number of failure types (4)
            dropout: Dropout probability
        """
        super().__init__()

        self.input_dim = input_dim
        self.num_horizons = num_horizons
        self.num_failure_types = num_failure_types
        self.output_dim = num_horizons * num_failure_types

        # Build MLP
        layers = []
        prev_dim = input_dim

        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, hidden_dim),
                nn.ReLU(),
                nn.BatchNorm1d(hidden_dim),
                nn.Dropout(dropout)
            ])
            prev_dim = hidden_dim

        # Output layer
        layers.append(nn.Linear(prev_dim, self.output_dim))

        self.network = nn.Sequential(*layers)

        # Initialize weights
        self._init_weights()

    def _init_weights(self):
        """Initialize network weights."""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, signals: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.

        Args:
            signals: VLA signals (B, 12) or (B, T, 12)

        Returns:
            predictions: Failure probabilities (B, 16) or (B, T, 16)
                        Shape: (batch, horizons * failure_types)
                        Output[i, h*4 + f] = P(failure_type=f at horizon=h | signals[i])
        """
        original_shape = signals.shape

        # Handle both (B, 12) and (B, T, 12) inputs
        if len(original_shape) == 3:
            B, T, D = original_shape
            signals = signals.reshape(B * T, D)

        # Forward pass
        logits = self.network(signals)

        # Apply sigmoid for probabilities
        predictions = torch.sigmoid(logits)

        # Reshape back if needed
        if len(original_shape) == 3:
            predictions = predictions.reshape(B, T, self.output_dim)

        return predictions

    def predict_at_horizon(
        self,
        signals: torch.Tensor,
        horizon_idx: int
    ) -> torch.Tensor:
        """
        Get predictions for a specific horizon.

        Args:
            signals: VLA signals (B, 12)
            horizon_idx: Horizon index (0-3)

        Returns:
            predictions: Failure probabilities (B, 4) for each failure type
        """
        all_predictions = self.forward(signals)

        # Extract predictions for this horizon
        start_idx = horizon_idx * self.num_failure_types
        end_idx = start_idx + self.num_failure_types

        return all_predictions[:, start_idx:end_idx]

    def get_max_failure_prob(self, signals: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Get maximum failure probability across all horizons and types.

        Args:
            signals: VLA signals (B, 12)

        Returns:
            max_prob: Maximum failure probability (B,)
            best_horizon: Horizon with max probability (B,)
            best_type: Failure type with max probability (B,)
        """
        predictions = self.forward(signals)  # (B, 16)
        predictions = predictions.reshape(-1, self.num_horizons, self.num_failure_types)  # (B, 4, 4)

        # Get max across horizons and types
        max_prob, max_idx = predictions.reshape(-1, self.num_horizons * self.num_failure_types).max(dim=1)

        best_horizon = max_idx // self.num_failure_types
        best_type = max_idx % self.num_failure_types

        return max_prob, best_horizon, best_type


class FailurePredictorLoss(nn.Module):
    """
    Loss function for failure predictor.

    Uses binary cross-entropy with class weighting to handle imbalance.
    """

    def __init__(
        self,
        pos_weight: float = 2.0,
        horizon_weights: torch.Tensor = None,
        type_weights: torch.Tensor = None
    ):
        """
        Initialize loss function.

        Args:
            pos_weight: Weight for positive (failure) class
            horizon_weights: Weights for each horizon (4,)
            type_weights: Weights for each failure type (4,)
        """
        super().__init__()

        self.pos_weight = pos_weight
        self.horizon_weights = horizon_weights
        self.type_weights = type_weights

        # BCE loss
        self.bce = nn.BCELoss(reduction='none')

    def forward(
        self,
        predictions: torch.Tensor,
        targets: torch.Tensor,
        mask: torch.Tensor = None
    ) -> torch.Tensor:
        """
        Compute loss.

        Args:
            predictions: Predicted probabilities (B, T, 16) or (B, 16)
            targets: Ground truth labels (B, T, 16) or (B, 16)
            mask: Valid timestep mask (B, T) or None

        Returns:
            loss: Scalar loss
        """
        # Compute BCE loss
        loss = self.bce(predictions, targets)  # (B, T, 16) or (B, 16)

        # Apply positive class weighting
        pos_mask = (targets > 0.5).float()
        loss = loss * (1.0 + pos_mask * (self.pos_weight - 1.0))

        # Apply horizon and type weights if provided
        if self.horizon_weights is not None or self.type_weights is not None:
            loss = loss.reshape(-1, 4, 4)  # (B*T, 4_horizons, 4_types)

            if self.horizon_weights is not None:
                loss = loss * self.horizon_weights.view(1, 4, 1).to(loss.device)

            if self.type_weights is not None:
                loss = loss * self.type_weights.view(1, 1, 4).to(loss.device)

            loss = loss.reshape(predictions.shape)

        # Apply mask if provided
        if mask is not None:
            if len(predictions.shape) == 3:
                mask = mask.unsqueeze(-1).expand_as(predictions)
            loss = loss * mask
            return loss.sum() / mask.sum()

        return loss.mean()


def create_failure_predictor(config: Dict = None) -> FailurePredictor:
    """
    Factory function to create failure predictor.

    Args:
        config: Configuration dict

    Returns:
        model: FailurePredictor instance
    """
    if config is None:
        config = {}

    return FailurePredictor(
        input_dim=config.get('input_dim', 12),
        hidden_dims=config.get('hidden_dims', [64, 128, 128, 64]),
        num_horizons=config.get('num_horizons', 4),
        num_failure_types=config.get('num_failure_types', 4),
        dropout=config.get('dropout', 0.2)
    )


if __name__ == "__main__":
    # Test predictor
    print("Testing Failure Predictor...")

    model = create_failure_predictor()
    print(f"Model: {model}")
    print(f"Parameters: {sum(p.numel() for p in model.parameters())}")

    # Test forward pass
    batch_size = 8
    signals = torch.randn(batch_size, 12)

    predictions = model(signals)
    print(f"\nInput shape: {signals.shape}")
    print(f"Output shape: {predictions.shape}")
    print(f"Output range: [{predictions.min():.3f}, {predictions.max():.3f}]")

    # Test temporal input
    signals_temporal = torch.randn(batch_size, 200, 12)
    predictions_temporal = model(signals_temporal)
    print(f"\nTemporal input shape: {signals_temporal.shape}")
    print(f"Temporal output shape: {predictions_temporal.shape}")

    # Test loss
    targets = torch.randint(0, 2, (batch_size, 16)).float()
    loss_fn = FailurePredictorLoss(pos_weight=2.0)
    loss = loss_fn(predictions, targets)
    print(f"\nLoss: {loss.item():.4f}")

    print("\n✅ Failure Predictor test passed!")
