"""synthesis module"""
