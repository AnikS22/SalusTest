"""
Compute failure labels for SALUS training.
Labels indicate whether a failure occurs within each horizon window.
"""

import numpy as np
import torch
from typing import Dict, Tuple
import zarr


def compute_failure_labels(
    episode_metadata: Dict,
    episode_length: int,
    max_episode_length: int = 200,
    horizons: list = [6, 9, 12, 15],  # 200ms, 300ms, 400ms, 500ms at 30Hz
    num_failure_types: int = 4
) -> np.ndarray:
    """
    Compute failure labels for an episode at multiple horizons.

    Args:
        episode_metadata: Dict with 'success', 'failure_type', 'episode_length'
        episode_length: Actual episode length
        max_episode_length: Maximum episode length (for padding)
        horizons: Time steps ahead to predict (in steps at 30Hz)
        num_failure_types: Number of failure types (4)

    Returns:
        labels: (T, num_horizons, num_failure_types) binary labels
    """
    success = episode_metadata['success']
    failure_type = episode_metadata['failure_type']
    actual_length = episode_metadata['episode_length']

    # Initialize labels (all zeros)
    labels = np.zeros((max_episode_length, len(horizons), num_failure_types), dtype=np.float32)

    # If episode succeeded, no failure labels
    if success:
        return labels

    # Failure occurred at timestep = actual_length
    failure_timestep = actual_length

    # For each timestep, check if failure is within horizon
    for t in range(actual_length):
        for h_idx, horizon in enumerate(horizons):
            # If failure is within this horizon from timestep t
            if t + horizon >= failure_timestep:
                # Set label for the failure type that occurred
                labels[t, h_idx, failure_type] = 1.0

    return labels


def compute_all_labels(
    zarr_path: str,
    horizons: list = [6, 9, 12, 15],
    control_freq: int = 30
) -> Tuple[np.ndarray, Dict]:
    """
    Compute failure labels for all episodes in dataset.

    Args:
        zarr_path: Path to zarr data
        horizons: Horizon steps (default 200ms, 300ms, 400ms, 500ms at 30Hz)
        control_freq: Control frequency in Hz

    Returns:
        labels: (N, T, num_horizons * num_failure_types) labels
        stats: Statistics about failures
    """
    print(f"Loading data from: {zarr_path}")
    store = zarr.open(zarr_path, mode='r+')

    num_episodes = store['actions'].shape[0]
    max_episode_length = store['actions'].shape[1]

    print(f"Episodes: {num_episodes}")
    print(f"Max episode length: {max_episode_length}")
    print(f"Horizons (steps): {horizons}")
    print(f"Horizons (ms): {[h * 1000 // control_freq for h in horizons]}")

    # Get episode metadata
    metadata_list = []
    success_count = 0
    failure_counts = {0: 0, 1: 0, 2: 0, 3: 0}

    for i in range(num_episodes):
        # Check if episode has data
        if store['actions'][i].max() == 0 and store['states'][i].max() == 0:
            print(f"Warning: Episode {i} has no data, skipping")
            continue

        # Get metadata (need to extract from zarr)
        # For now, we'll need to infer from the data
        # TODO: Store metadata properly during collection
        metadata = {
            'success': False,  # Assume failure for now
            'failure_type': 3,  # Default to "other"
            'episode_length': max_episode_length  # Assume full length
        }
        metadata_list.append(metadata)

        if metadata['success']:
            success_count += 1
        else:
            failure_counts[metadata['failure_type']] += 1

    print(f"\n📊 Episode Statistics:")
    print(f"   Success: {success_count}/{num_episodes} ({success_count/num_episodes*100:.1f}%)")
    print(f"   Failures by type:")
    for ftype, count in failure_counts.items():
        type_names = {0: "none", 1: "drop", 2: "timeout", 3: "other"}
        print(f"      {type_names[ftype]}: {count}/{num_episodes} ({count/num_episodes*100:.1f}%)")

    # Compute labels for all episodes
    print(f"\nComputing failure labels...")
    all_labels = []

    for i, metadata in enumerate(metadata_list):
        labels = compute_failure_labels(metadata, max_episode_length, max_episode_length, horizons, 4)
        # Flatten: (T, H, F) -> (T, H*F)
        labels_flat = labels.reshape(max_episode_length, -1)
        all_labels.append(labels_flat)

    all_labels = np.stack(all_labels, axis=0)  # (N, T, H*F)
    print(f"Labels shape: {all_labels.shape}")

    # Compute statistics
    stats = {
        'num_episodes': len(metadata_list),
        'success_count': success_count,
        'failure_counts': failure_counts,
        'success_rate': success_count / len(metadata_list),
        'label_positive_rate': (all_labels > 0).sum() / all_labels.size,
        'horizons': horizons,
        'horizons_ms': [h * 1000 // control_freq for h in horizons]
    }

    print(f"\n📈 Label Statistics:")
    print(f"   Positive labels: {stats['label_positive_rate']*100:.2f}%")

    # Save labels to zarr
    if 'horizon_labels' in store:
        print(f"\nDeleting existing horizon_labels and recreating...")
        del store['horizon_labels']

    print(f"Creating new horizon_labels in zarr...")
    store['horizon_labels'] = all_labels

    print(f"✅ Labels saved to zarr")

    return all_labels, stats


if __name__ == "__main__":
    import sys
    from pathlib import Path

    if len(sys.argv) < 2:
        print("Usage: python preprocess_labels.py <zarr_path>")
        sys.exit(1)

    zarr_path = sys.argv[1]

    if not Path(zarr_path).exists():
        print(f"Error: {zarr_path} does not exist")
        sys.exit(1)

    # Compute labels
    labels, stats = compute_all_labels(zarr_path)

    print(f"\n✅ Label computation complete!")
    print(f"   Saved to: {zarr_path}/horizon_labels")
