"""
SALUS MVP Dataset
Simple PyTorch dataset for loading episodes from Zarr

Loads 6D signals and failure labels for training the MVP predictor
"""

import torch
import numpy as np
import zarr
from pathlib import Path
from torch.utils.data import Dataset, DataLoader
from typing import Dict, List, Tuple, Optional
import json


class SALUSMVPDataset(Dataset):
    """
    PyTorch Dataset for SALUS MVP training

    Loads 6D signals and failure labels from Zarr episodes
    """

    def __init__(
        self,
        data_dir: str,
        split: str = 'train',
        train_ratio: float = 0.8,
        max_episodes: Optional[int] = None
    ):
        """
        Args:
            data_dir: Path to directory with data.zarr
            split: 'train' or 'val'
            train_ratio: Ratio of episodes for training
            max_episodes: Optional limit on episodes to load
        """
        self.data_dir = Path(data_dir)
        self.split = split

        # Load Zarr data
        zarr_path = self.data_dir / 'data.zarr'
        if not zarr_path.exists():
            raise FileNotFoundError(f"Zarr data not found at {zarr_path}")

        self.zarr_root = zarr.open_group(str(zarr_path), mode='r')

        # Get number of episodes from signals shape
        self.num_episodes = self.zarr_root['signals'].shape[0]
        if max_episodes is not None:
            self.num_episodes = min(self.num_episodes, max_episodes)

        # Split into train/val
        split_idx = int(self.num_episodes * train_ratio)
        if split == 'train':
            self.episode_indices = list(range(split_idx))
        else:
            self.episode_indices = list(range(split_idx, self.num_episodes))

        # Build index: (episode_idx, timestep_idx)
        self.samples = []
        for ep_idx in self.episode_indices:
            # Get episode metadata to find actual length
            metadata_str = str(self.zarr_root['episode_metadata'][ep_idx])
            if metadata_str:
                ep_metadata = json.loads(metadata_str)
                ep_length = ep_metadata.get('episode_length', 200)
            else:
                ep_length = 200

            # Add all timesteps from this episode
            for t in range(ep_length):
                self.samples.append((ep_idx, t))

        print(f"Loaded {split} dataset: {len(self.samples)} samples from {len(self.episode_indices)} episodes")

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Get a single training sample

        Returns:
            signals: (6,) tensor of uncertainty signals
            labels: (4,) tensor of failure types (multi-label, from horizon_labels)
        """
        ep_idx, t = self.samples[idx]

        # Get 6D signals at this timestep
        signals = torch.from_numpy(np.array(self.zarr_root['signals'][ep_idx, t])).float()  # (6,)

        # Get horizon labels for this timestep
        # horizon_labels shape: (num_episodes, 200, 4_horizons, 4_classes)
        # We use the last horizon (20 steps) for now
        horizon_labels = self.zarr_root['horizon_labels'][ep_idx, t]  # (4_horizons, 4_classes)

        # Use the longest horizon (index 3 = 20 steps ahead)
        labels = torch.from_numpy(np.array(horizon_labels[3])).float()  # (4,)

        return signals, labels

    def get_statistics(self) -> Dict:
        """Compute dataset statistics"""
        # Count failure types
        failure_counts = {0: 0, 1: 0, 2: 0, 3: 0}
        success_count = 0

        for ep_idx in self.episode_indices:
            metadata_str = str(self.zarr_root['episode_metadata'][ep_idx])
            if metadata_str:
                ep_metadata = json.loads(metadata_str)
                success = ep_metadata.get('success', True)
                failure_type = ep_metadata.get('failure_type', -1)
            else:
                success = True
                failure_type = -1

            if success:
                success_count += 1
            elif 0 <= failure_type < 4:
                failure_counts[failure_type] += 1

        return {
            'num_episodes': len(self.episode_indices),
            'num_samples': len(self.samples),
            'success_count': success_count,
            'failure_counts': failure_counts,
            'failure_names': {
                0: 'Collision',
                1: 'Drop',
                2: 'Miss',
                3: 'Timeout'
            }
        }

    def close(self):
        """Close Zarr file"""
        if hasattr(self, 'zarr_root'):
            self.zarr_root.store.close()


def create_dataloaders(
    data_dir: str,
    batch_size: int = 32,
    train_ratio: float = 0.8,
    max_episodes: Optional[int] = None,
    num_workers: int = 2
) -> Tuple[DataLoader, DataLoader]:
    """
    Create train and validation dataloaders

    Args:
        data_dir: Path to data directory
        batch_size: Batch size
        train_ratio: Train/val split ratio
        max_episodes: Optional limit on episodes
        num_workers: Number of dataloader workers

    Returns:
        train_loader, val_loader
    """
    train_dataset = SALUSMVPDataset(
        data_dir=data_dir,
        split='train',
        train_ratio=train_ratio,
        max_episodes=max_episodes
    )

    val_dataset = SALUSMVPDataset(
        data_dir=data_dir,
        split='val',
        train_ratio=train_ratio,
        max_episodes=max_episodes
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )

    return train_loader, val_loader


# Test
if __name__ == "__main__":
    print("🧪 Testing SALUS MVP Dataset...\n")

    # Test with dummy data directory
    import sys
    if len(sys.argv) > 1:
        data_dir = sys.argv[1]
    else:
        print("Usage: python dataset_mvp.py <data_dir>")
        print("Example: python dataset_mvp.py data/mvp_episodes/20260102_120000")
        sys.exit(1)

    print(f"Loading data from: {data_dir}\n")

    # Create datasets
    try:
        train_dataset = SALUSMVPDataset(data_dir, split='train', train_ratio=0.8)
        val_dataset = SALUSMVPDataset(data_dir, split='val', train_ratio=0.8)

        print("📊 Dataset Statistics:")
        print("\nTrain:")
        train_stats = train_dataset.get_statistics()
        print(f"   Episodes: {train_stats['num_episodes']}")
        print(f"   Samples: {train_stats['num_samples']}")
        print(f"   Success: {train_stats['success_count']}")
        print(f"   Failures:")
        for ftype, count in train_stats['failure_counts'].items():
            fname = train_stats['failure_names'][ftype]
            print(f"     {fname}: {count}")

        print("\nVal:")
        val_stats = val_dataset.get_statistics()
        print(f"   Episodes: {val_stats['num_episodes']}")
        print(f"   Samples: {val_stats['num_samples']}")
        print(f"   Success: {val_stats['success_count']}")
        print(f"   Failures:")
        for ftype, count in val_stats['failure_counts'].items():
            fname = val_stats['failure_names'][ftype]
            print(f"     {fname}: {count}")

        # Test data loading
        print("\n🔄 Testing data loading...")
        signals, labels = train_dataset[0]
        print(f"   Signal shape: {signals.shape}")
        print(f"   Label shape: {labels.shape}")
        print(f"   Signal range: [{signals.min():.3f}, {signals.max():.3f}]")
        print(f"   Label sum: {labels.sum():.0f}")

        # Test dataloader
        print("\n🔄 Testing DataLoader...")
        train_loader, val_loader = create_dataloaders(
            data_dir,
            batch_size=8,
            num_workers=0
        )

        signals_batch, labels_batch = next(iter(train_loader))
        print(f"   Batch signals shape: {signals_batch.shape}")
        print(f"   Batch labels shape: {labels_batch.shape}")

        print("\n✅ Dataset test passed!")

        # Cleanup
        train_dataset.close()
        val_dataset.close()

    except FileNotFoundError as e:
        print(f"❌ Error: {e}")
        print("\nMake sure you've collected data first:")
        print("python scripts/collect_episodes_mvp.py --num_episodes 10")
