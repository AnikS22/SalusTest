"""
Scalable Data Recorder for SALUS
Uses Zarr for efficient chunked storage, supports TB-scale datasets
"""

import zarr
import numcodecs
import numpy as np
from pathlib import Path
from typing import Dict, Any, Optional, List
import json
from datetime import datetime
import threading
from collections import deque


class ScalableDataRecorder:
    """
    Records episode data efficiently using Zarr format

    Features:
    - Chunked storage for TB-scale datasets
    - Compression (zstd)
    - Thread-safe concurrent writes
    - Automatic checkpointing
    - Memory efficient
    """

    def __init__(
        self,
        save_dir: Path,
        max_episodes: int,
        max_episode_length: int,
        image_shape: tuple = (3, 256, 256),
        state_dim: int = 7,
        action_dim: int = 7,
        signal_dim: int = 12,
        num_cameras: int = 3,
        chunk_size: int = 100,
        compression: str = "zstd"
    ):
        """
        Initialize recorder

        Args:
            save_dir: Directory to save data
            max_episodes: Maximum number of episodes
            max_episode_length: Max timesteps per episode
            image_shape: Shape of camera images (C, H, W)
            state_dim: Robot state dimension
            action_dim: Action dimension
            signal_dim: Signal feature dimension
            num_cameras: Number of cameras
            chunk_size: Episodes per chunk (for efficient I/O)
            compression: Compression algorithm
        """
        self.save_dir = Path(save_dir)
        self.save_dir.mkdir(parents=True, exist_ok=True)

        self.max_episodes = max_episodes
        self.max_episode_length = max_episode_length
        self.image_shape = image_shape
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.signal_dim = signal_dim
        self.num_cameras = num_cameras
        self.chunk_size = chunk_size

        # Thread safety
        self.lock = threading.Lock()
        self.current_episode_idx = 0

        # Episode buffer (in memory)
        self.episode_buffer = deque(maxlen=10)

        # Initialize Zarr store
        self._init_zarr_store(compression)

        print(f"\n📦 Scalable Data Recorder Initialized")
        print(f"   Save directory: {self.save_dir}")
        print(f"   Max episodes: {max_episodes}")
        print(f"   Chunk size: {chunk_size} episodes")
        print(f"   Compression: {compression}")
        print(f"   Estimated size: ~{self._estimate_size():.2f} GB")

    def _init_zarr_store(self, compression: str):
        """Initialize Zarr arrays for efficient storage"""

        store_path = self.save_dir / "data.zarr"
        self.zarr_store = zarr.open(str(store_path), mode='a')

        # Create arrays if they don't exist (Zarr v3 uses default compression)
        if 'images' not in self.zarr_store:
            # Images: (episodes, timesteps, cameras, C, H, W)
            self.zarr_store.create_array(
                'images',
                shape=(self.max_episodes, self.max_episode_length, self.num_cameras, *self.image_shape),
                chunks=(self.chunk_size, 10, 1, *self.image_shape),  # Chunk-friendly
                dtype='uint8'
            )

        if 'states' not in self.zarr_store:
            # States: (episodes, timesteps, state_dim)
            self.zarr_store.create_array(
                'states',
                shape=(self.max_episodes, self.max_episode_length, self.state_dim),
                chunks=(self.chunk_size, self.max_episode_length, self.state_dim),
                dtype='float32'
            )

        if 'actions' not in self.zarr_store:
            # Actions: (episodes, timesteps, action_dim)
            self.zarr_store.create_array(
                'actions',
                shape=(self.max_episodes, self.max_episode_length, self.action_dim),
                chunks=(self.chunk_size, self.max_episode_length, self.action_dim),
                dtype='float32'
            )

        if 'signals' not in self.zarr_store:
            # Signals: (episodes, timesteps, signal_dim)
            self.zarr_store.create_array(
                'signals',
                shape=(self.max_episodes, self.max_episode_length, self.signal_dim),
                chunks=(self.chunk_size, self.max_episode_length, self.signal_dim),
                dtype='float32'
            )

        if 'horizon_labels' not in self.zarr_store:
            # Horizon labels: (episodes, timesteps, horizons, failure_types)
            self.zarr_store.create_array(
                'horizon_labels',
                shape=(self.max_episodes, self.max_episode_length, 4, 4),
                chunks=(self.chunk_size, self.max_episode_length, 4, 4),
                dtype='float32'
            )

        # Metadata: Episode-level info - store as JSON strings in Zarr v3
        if 'episode_metadata' not in self.zarr_store:
            self.zarr_store.create_array(
                'episode_metadata',
                shape=(self.max_episodes,),
                dtype='<U1000',  # Unicode string, max 1000 chars
                fill_value=""
            )

        print(f"   ✅ Zarr store initialized at {store_path}")

    def record_episode(
        self,
        episode_data: Dict[str, np.ndarray],
        metadata: Dict[str, Any]
    ):
        """
        Record a single episode (thread-safe)

        Args:
            episode_data: Dict containing:
                - 'images': (T, num_cameras, C, H, W)
                - 'states': (T, state_dim)
                - 'actions': (T, action_dim)
                - 'signals': (T, signal_dim)
                - 'horizon_labels': (T, 4, 4)
            metadata: Dict with episode info (success, failure_type, etc.)
        """
        with self.lock:
            if self.current_episode_idx >= self.max_episodes:
                raise ValueError(f"Maximum episodes ({self.max_episodes}) reached!")

            episode_idx = self.current_episode_idx
            self.current_episode_idx += 1

        # Get episode length
        T = episode_data['states'].shape[0]

        # Write to Zarr (thread-safe)
        self.zarr_store['images'][episode_idx, :T] = episode_data['images']
        self.zarr_store['states'][episode_idx, :T] = episode_data['states']
        self.zarr_store['actions'][episode_idx, :T] = episode_data['actions']
        self.zarr_store['signals'][episode_idx, :T] = episode_data['signals']
        self.zarr_store['horizon_labels'][episode_idx, :T] = episode_data['horizon_labels']

        # Save metadata as JSON string
        metadata['episode_idx'] = int(episode_idx)
        metadata['episode_length'] = int(T)
        metadata['timestamp'] = datetime.now().isoformat()
        self.zarr_store['episode_metadata'][episode_idx] = json.dumps(metadata)

        return episode_idx

    def get_episode(self, episode_idx: int) -> Dict[str, np.ndarray]:
        """Load a specific episode"""
        if episode_idx >= self.current_episode_idx:
            raise ValueError(f"Episode {episode_idx} not recorded yet")

        metadata_str = str(self.zarr_store['episode_metadata'][episode_idx])
        metadata = json.loads(metadata_str) if metadata_str else {}
        T = metadata.get('episode_length', self.max_episode_length)

        return {
            'images': self.zarr_store['images'][episode_idx, :T],
            'states': self.zarr_store['states'][episode_idx, :T],
            'actions': self.zarr_store['actions'][episode_idx, :T],
            'signals': self.zarr_store['signals'][episode_idx, :T],
            'horizon_labels': self.zarr_store['horizon_labels'][episode_idx, :T],
            'metadata': metadata
        }

    def get_statistics(self) -> Dict[str, Any]:
        """Get dataset statistics"""
        n_episodes = self.current_episode_idx

        if n_episodes == 0:
            return {"num_episodes": 0}

        # Compute stats
        success_count = 0
        total_timesteps = 0

        for i in range(n_episodes):
            metadata_str = str(self.zarr_store['episode_metadata'][i])
            if metadata_str:
                metadata = json.loads(metadata_str)
                if metadata.get('success', False):
                    success_count += 1
                total_timesteps += metadata.get('episode_length', 0)

        return {
            "num_episodes": n_episodes,
            "success_rate": success_count / n_episodes if n_episodes > 0 else 0,
            "total_timesteps": total_timesteps,
            "storage_size_gb": self._compute_storage_size()
        }

    def save_checkpoint(self, checkpoint_path: Optional[Path] = None):
        """Save checkpoint with metadata"""
        if checkpoint_path is None:
            checkpoint_path = self.save_dir / f"checkpoint_{self.current_episode_idx}.json"

        checkpoint_data = {
            "num_episodes_recorded": self.current_episode_idx,
            "timestamp": datetime.now().isoformat(),
            "statistics": self.get_statistics()
        }

        with open(checkpoint_path, 'w') as f:
            json.dump(checkpoint_data, f, indent=2)

        print(f"   💾 Checkpoint saved: {checkpoint_path}")

    def _estimate_size(self) -> float:
        """Estimate dataset size in GB (uncompressed)"""
        # Images: uint8
        image_size = (
            self.max_episodes * self.max_episode_length *
            self.num_cameras * np.prod(self.image_shape)
        ) / 1e9

        # States, actions, signals: float32
        state_size = (
            self.max_episodes * self.max_episode_length *
            (self.state_dim + self.action_dim + self.signal_dim) * 4
        ) / 1e9

        # Labels: float32
        label_size = (self.max_episodes * self.max_episode_length * 4 * 4 * 4) / 1e9

        return image_size + state_size + label_size

    def _compute_storage_size(self) -> float:
        """Compute actual storage size in GB"""
        total_size = 0
        for path in self.save_dir.rglob("*"):
            if path.is_file():
                total_size += path.stat().st_size
        return total_size / 1e9

    def close(self):
        """Close Zarr store"""
        self.zarr_store.store.close()
        print(f"   ✅ Data recorder closed")


# Test the recorder
if __name__ == "__main__":
    print("Testing Scalable Data Recorder...\n")

    # Create recorder
    recorder = ScalableDataRecorder(
        save_dir=Path("data/test_recorder"),
        max_episodes=100,
        max_episode_length=200,
        chunk_size=10
    )

    # Simulate recording episodes
    print("\n📝 Recording test episodes...")
    for i in range(5):
        # Create dummy episode data
        T = np.random.randint(50, 200)  # Variable length
        episode_data = {
            'images': np.random.randint(0, 255, (T, 3, 3, 256, 256), dtype=np.uint8),
            'states': np.random.randn(T, 7).astype(np.float32),
            'actions': np.random.randn(T, 7).astype(np.float32),
            'signals': np.random.randn(T, 12).astype(np.float32),
            'horizon_labels': np.random.rand(T, 4, 4).astype(np.float32)
        }

        metadata = {
            'success': np.random.rand() > 0.5,
            'failure_type': int(np.random.randint(0, 4)) if np.random.rand() > 0.5 else None
        }

        episode_idx = recorder.record_episode(episode_data, metadata)
        print(f"   Episode {episode_idx}: {T} timesteps, success={metadata['success']}")

    # Get statistics
    print("\n📊 Dataset Statistics:")
    stats = recorder.get_statistics()
    for key, value in stats.items():
        print(f"   {key}: {value}")

    # Save checkpoint
    recorder.save_checkpoint()

    # Test loading
    print("\n📖 Testing episode loading...")
    episode = recorder.get_episode(0)
    print(f"   Loaded episode 0: {episode['states'].shape[0]} timesteps")

    recorder.close()
    print("\n✅ All tests passed!")
